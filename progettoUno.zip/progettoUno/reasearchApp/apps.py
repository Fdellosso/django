from django.apps import AppConfig


class ReasearchappConfig(AppConfig):
    name = 'reasearchApp'
