from django.urls import path
from . import views

urlpatterns = [
    path('paginaPrincipale/', views.paginaPrincipale, name='paginaPrincipale'),
    path('secondaProva/', views.secondaProva, name='secondaProva'),
]
