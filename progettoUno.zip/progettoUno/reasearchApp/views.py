from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def paginaPrincipale(request):
    #return HttpResponse('<h1>INSERISCI NUOVO UTENTE</h1>')
    return render(request, '../templates/prova.html')

def secondaProva(request):
    return render(request, '../templates/secondaProva.html')
